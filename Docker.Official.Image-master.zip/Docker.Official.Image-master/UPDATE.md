# Instuctions to update

```
./update.sh
./generate-stackbrew-library.sh > ../official-images/library/rocket.chat
cd ../official-images
#git commit && git push && PR
```
